import winreg


# 获取个性化颜色函数
def get_windows_system_color():
    color_key_path = r"Software\Microsoft\Windows\DWM"
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, color_key_path)
        value, _ = winreg.QueryValueEx(key, "ColorizationColor")
        alpha = (value >> 24) & 0xFF
        red = (value >> 16) & 0xFF
        green = (value >> 8) & 0xFF
        blue = value & 0xFF
        return red, green, blue, alpha
    except Exception as e:
        return repr(e)


# 获取个性化颜色
def get_Oldwindows_system_color():
    color_key_path = r"Control Panel\Colors"
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, color_key_path)
        value, _ = winreg.QueryValueEx(key, "ColorizationColor")
        alpha = (value >> 24) & 0xFF
        red = (value >> 16) & 0xFF
        green = (value >> 8) & 0xFF
        blue = value & 0xFF
        return red, green, blue, alpha
    except Exception as e:
        return repr(e)
