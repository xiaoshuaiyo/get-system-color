import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()


setuptools.setup(
    name="get-system-color",
    version="1.0.0",
    author="xiaoshuaiYo",
    author_email="619396351@qq.com",
    description="这个包可以获取windows平台的主题色",
    long_description=long_description,
    long_description_content_type="text/markdown",
    license="Apache2",
    url="https://github.com/xiaoshuaiyo/get-system-color",
    packages=setuptools.find_packages(),
    install_requires=[
        "winreg>=0.1.1",
    ],
    extras_require = {
        'full': ['scipy', 'pillow<=9.4.0', 'colorthief']
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: Apache2',
        'Operating System :: OS Independent'
    ],
    project_urls={
        'Source Code': 'https://github.com/xiaoshuaiyo/get-system-color',
        'Bug Tracker': 'https://github.com/xiaoshuaiyo/get-system-color/issues',
    }
)
