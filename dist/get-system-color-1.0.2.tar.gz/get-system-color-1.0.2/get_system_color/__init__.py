# -*- coding:utf-8 -*-
"""
get_system_color is a Python module.
Copyright (c) 2023 xiaoshuaiYO
"""
from .get_color import get_windows_system_color, get_Oldwindows_system_color, On_theme_change, ThemeColorMonitor


__version__ = "1.0.0"


